package com.nooul.apihelpers.springbootrest.helpers.repositories;

import com.nooul.apihelpers.springbootrest.helpers.entities.Actor;
import com.nooul.apihelpers.springbootrest.repositories.BaseRepository;

public interface ActorRepository extends BaseRepository<Actor, Long> {
}
