package com.nooul.apihelpers.springbootrest.helpers.repositories;

import com.nooul.apihelpers.springbootrest.helpers.entities.Director;
import com.nooul.apihelpers.springbootrest.repositories.BaseRepository;

public interface DirectorRepository extends BaseRepository<Director, Long> {
}
