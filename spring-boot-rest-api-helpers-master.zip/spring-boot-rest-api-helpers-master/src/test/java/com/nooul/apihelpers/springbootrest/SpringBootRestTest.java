package com.nooul.apihelpers.springbootrest;

import org.junit.jupiter.api.Test;

public class SpringBootRestTest extends AbstractSpringBootTest {

    @Test
    public void contextLoads() {
    }


}
